#include "communication.h"
#include "device_list.h"
#include "network.h"
using namespace std;

int main()
{
    user new_user;
    new_user.main_program();

	return 0;
}
